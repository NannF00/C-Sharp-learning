﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextBox= System.Windows.Forms.TextBox;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Markup;
using static System.Net.Mime.MediaTypeNames;
//using System.Collections.Generic;


namespace Sodoko
{

    public partial class Form1 : Form
    {

        TextBox[,] textBoxList = new TextBox[9, 9];

        TextBox[,] itextBoxList = new TextBox[9, 9];

        List<int>[,] emptyList = new List<int>[9, 9];//成功了!去掉最后的括号!

        List<int>[,] iemptyList = new List<int>[9, 9];

        int z = 100;

        int[,] aufgabe =
                        {
                        {0,0,0,0,0,0,9,4,5},
                        {0,0,6,0,0,0,0,0,0},
                        {5,2,0,1,0,3,8,0,7},
                        {0,9,0,3,1,0,0,0,0},
                        {0,0,3,0,8,0,1,0,0},
                        {0,0,0,0,4,6,0,2,0},
                        {7,0,5,2,0,8,0,1,9},
                        {0,0,0,0,0,0,3,0,0},
                        {8,6,1,0,0,0,0,0,0}
                        };
        //int[,] aufgabe =
        //                {
        //                {8,0,0,0,0,0,0,0,0},
        //                {0,0,3,6,0,0,0,0,0},
        //                {0,7,0,0,9,0,2,0,0},
        //                {0,5,0,0,0,7,0,0,0},
        //                {0,0,0,0,4,5,7,0,0},
        //                {0,0,0,1,0,0,0,3,0},
        //                {0,0,1,0,0,0,0,6,8},
        //                {0,0,8,5,0,0,0,1,0},
        //                {0,9,0,0,0,0,4,0,0}
        //                };
        public Form1()
        {
            InitializeComponent();
            Initialize();
        }
        /// <summary>
        /// MouseDoubleClick 双击准备解决
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Readytogo_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //设置所有题目位为只读 ,设置所有空格子的List为1-9
            foreach (var item in textBoxList)
            {
                if (item.Text != "")
                {
                    item.ReadOnly = true;
                }
                else
                {
                    int[] n = new int[9] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                    List<int> emptyBox = n.ToList();
                    int a = item.TabIndex / 9;//行
                    int b = item.TabIndex % 9;//列
                    emptyList[a, b] = emptyBox;
                }
            }
            //初始化空白格子的可能性
            foreach (var item in textBoxList)
            {
                if (item.Text != "")
                {
                    DeleteRelativNummber(item, textBoxList,emptyList);
                }
            }
            //开始遍历每一个空TextBox,如果遍历完数独还是没填完,启动猜数环节
            LoopEmptyTextBox(textBoxList, emptyList);
            if (!IfFinished(textBoxList))
            {
                UpDateList(textBoxList, emptyList);

            }
            return;//填完了
            #region
            ////用不能再往下填的原表初始化虚表
            //UpDateList(textBoxList, emptyList);
            //用找2找
            //for (int i = 0; i <= 50; i++)
            //{
            //    if (!IfFinished(textBoxList))
            //    {
            //        int a;
            //        int b;
            //        //开始猜数,只要数独没解完就一直猜
            //        if (!FindPossib2(textBoxList, emptyList, out a, out b))
            //        {
            //            textBoxList[a, b].Text = emptyList[a, b][1].ToString();
            //        }
            //        LoopEmptyTextBox(textBoxList, emptyList);
            //        UpDateList(textBoxList, emptyList);
            //    }
            //    else
            //    {
            //        break;
            //    }
            //}


            //if (FindPossib3(textBoxList, emptyList, out a, out b))
            //{
            //    textBoxList[a, b].Text = emptyList[a, b][z].ToString();
            //}
            //LoopEmptyTextBox(textBoxList, emptyList);
            //UpDateList(textBoxList, emptyList);
            #endregion
        }

        public void UpDateList(TextBox[,] tList, List<int>[,] eList)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (tList[i, j].Text != "")
                    {
                        if (tList==textBoxList)//判断传进来的是哪个列表,决定用谁更新谁;
                        {
                            itextBoxList[i, j].Text = tList[i, j].Text;
                        }
                        else
                        {
                            textBoxList[i, j].Text = tList[i, j].Text;
                        }
                    }
                    else
                    {
                        int[] ints = new int[eList[i, j].Count];
                        for (int n = 0; n < eList[i, j].Count; n++)
                        {
                            ints[n] = Convert.ToInt32(eList[i, j][n]);
                        }
                        List<int> list = ints.ToList();
                        if (tList == textBoxList)
                        {
                            iemptyList[i, j] = list;
                        }
                        else
                        {
                            emptyList[i, j] = list;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// 遍历TextBox
        /// </summary>
        /// <param name="item"></param>
        public void LoopEmptyTextBox(TextBox[,] textBoxList, List<int>[,] emptyList)
        {
            foreach (var item in textBoxList)
            {
                if (item.Text == "")//空格子
                {
                    //判断能不能填,能填填上
                    while (IfFilled(item))
                    {
                        DeleteRelativNummber(item,textBoxList,emptyList);
                    }
                }
            }
        }
        public bool IfFilled(TextBox item)
        {
            int a = item.TabIndex / 9;//行
            int b = item.TabIndex % 9;//列
            if (emptyList[a, b].Count!=0)
            {
                int[] ints = emptyList[a, b].ToArray();
                string text = ints[0].ToString();
                if (emptyList[a, b].Count == 1 && IfHandled(item, text))
                {
                    item.Text = text;
                    return true;
                }
            }
            return false;
        }
        public void Initialize()
        {

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (((i >= 0 && i <= 2) || (i >= 6 && i <= 8)) && ((j >= 0 && j <= 2) || (j >= 6 && j <= 8)))
                    {

                        textBoxList[i, j] = Create1(i, j, System.Drawing.SystemColors.ActiveBorder);
                        itextBoxList[i, j] = Create2(i, j);
                    }
                    else if ((i >= 3 && i <= 5) && (j >= 3 && j <= 5))
                    {
                        textBoxList[i, j] = Create1(i, j, System.Drawing.SystemColors.ActiveBorder);
                        itextBoxList[i, j] = Create2(i, j);
                    }
                    else
                    {
                        textBoxList[i, j] = Create1(i, j, System.Drawing.SystemColors.ButtonFace);
                        itextBoxList[i, j] = Create2(i, j);
                    }

                }
            }
            //开始解决方案按钮
            Label readytogo = new Label()
            {
                MinimumSize = new Size(135, 45),
                Width = 135,
                Height = 45,
                Location = new Point(this.Width / 2 + 67, this.Height / 2 + 205),
                Anchor = AnchorStyles.None, //使控件随窗口大小变化
            };
            readytogo.Text = "READY TO GO";
            // readytogo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            readytogo.Font = new System.Drawing.Font("Bahnschrift SemiBold", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // readytogo.ReadOnly = true;
            readytogo.MouseDoubleClick += Readytogo_MouseDoubleClick;
            Controls.Add(readytogo);
        }
        public void DeleteRelativNummber(TextBox textBox, TextBox[,] tList, List<int>[,] emptyList)
        {
            int a = textBox.TabIndex / 9;//行
            int b = textBox.TabIndex % 9;//列
            //删同行.
            //挨个找到同行不为Null元素的Index.删除
            for (int i = 0; i < 9; i++)
            {
                if (tList[a, i].Text == "")
                {
                    emptyList[a, i].Remove(Convert.ToInt32(textBox.Text));
                    if (IfFilled(tList[a, i]))
                    {
                        DeleteRelativNummber(tList[a, i],tList,emptyList);
                    }
                }
            }
            //删同列
            for (int i = 0; i < 9; i++)
            {
                if (tList[i, b].Text == "")
                {
                    emptyList[i, b].Remove(Convert.ToInt32(textBox.Text));
                    if (IfFilled(tList[i, b]))
                    {
                        DeleteRelativNummber(textBoxList[i, b],tList,emptyList);
                    }
                }
                
            }
            //删3*3
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (tList[3 * (a / 3) + i, 3 * (b / 3) + j].Text == "")
                    {
                        emptyList[3 * (a / 3) + i, 3 * (b / 3) + j].Remove(Convert.ToInt32(textBox.Text));
                        if (IfFilled(tList[3 * (a / 3) + i, 3 * (b / 3) + j]))
                        {
                            DeleteRelativNummber(tList[3 * (a / 3) + i, 3 * (b / 3) + j],tList,emptyList);
                        }
                    }
                }
            }
        }
        private TextBox Create1(int i, int j, Color color)
        {
            TextBox textBox = new TextBox()
            {
                MinimumSize = new Size(45, 45),
                Width = 45,
                Height = 45,
                Location = new Point(this.Width / 2 - 202 + j * 45, this.Height / 2 - 202 + i * 45),//获取当前窗口的大小
                Anchor = AnchorStyles.None, //使控件随窗口大小变化
                TextAlign = HorizontalAlignment.Center,
                TabIndex = 9 * i + j,
                Name = "textBox" + TabIndex,
            };
            textBox.Font = new System.Drawing.Font("Bahnschrift SemiBold", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            textBox.BackColor = color;
            textBox.KeyPress += textBox_KeyPress;
            if (aufgabe[i, j]!=0)
            {
                textBox.Text = aufgabe[i, j].ToString();
            }
            textBox.TextChanged += TextBox_TextChanged;
            Controls.Add(textBox);

            return textBox;
        }
        public TextBox Create2(int i, int j)
        {
            TextBox textBox = new TextBox(){ TabIndex = 9 * i + j, };
            return textBox;
        }
        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            TextBox textBox = sender as TextBox;
            int a = textBox.TabIndex / 9;//行
            int b = textBox.TabIndex % 9;//列
            textBox.Text = textBox.Text;
            textBox.ForeColor = Color.Violet;
        }
        /// <summary>
        /// 设置只能输入1-9
        /// set only input 1-9
        /// 不让重复
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="KeyPressEvent"></param>
        public void textBox_KeyPress(object sender, KeyPressEventArgs KeyPressEvent)
        {
            TextBox textBox = (TextBox)sender;
            //handled:什么情况下拦截:不是数字编拦截,为0时拦截
            KeyPressEvent.Handled = !char.IsDigit(KeyPressEvent.KeyChar) || KeyPressEvent.KeyChar == '0';
            //违反规则不能填
            if (KeyPressEvent.Handled==true)
            {
                return;
            }
            string keyperssenent = KeyPressEvent.KeyChar.ToString();
            KeyPressEvent.Handled=!IfHandled(textBox, keyperssenent);
        }
        public bool IfHandled(TextBox textBox,string input)
        {
            bool iffilled = true;
            int a = textBox.TabIndex / 9;//行
            int b = textBox.TabIndex % 9;//列
            
            for (int j = 0; j < 9; j++)
            {
                if (j!=b&&textBoxList[a, j].Text == input)
                {
                    return iffilled = false;
                }
            }
            //同列
            for (int i = 0; i < 9; i++)
            {
                if (i!=a&&textBoxList[i, b].Text == input)
                {
                    return iffilled = false;
                }
            }
            //3*3
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i!=a&&j!=b&&textBoxList[3 * (a / 3) + i, 3 * (b / 3) + j].Text == input)
                    {
                        return iffilled = false;
                    }
                }
            }
            return iffilled;
        }
        public bool IfFinished(TextBox[,] textBoxList)
        {
            foreach (var item in textBoxList)
            {
                if (item.Text == "")
                {
                    return false;
                }
            }
            return true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// 排除掉(n,n)情况
        /// </summary>
        /// <param name="item"></param>
        public void ExcludeGruppe(TextBox item)
        {
            int a = item.TabIndex / 9;//行
            int b = item.TabIndex % 9;//列
            #region commented
            ////同行.
            //Dictionary<int, List<int>> bb = new Dictionary<int, List<int>>();//记录数字和位置
            //string r = "row";
            //for (int j = 0; j < 9; j++)//j 列数
            //{
            //    if (textBoxList[a, j].Text == "")//对每个textBox内的小array进行寻找
            //    {
            //        for (int n = 1; n < 10; n++)//有没有元素1-9
            //        {
            //            if (emptyList[a, j].Contains(n))
            //            {
            //                if (bb.ContainsKey(n))
            //                {
            //                    bb[n].Add(j);
            //                }
            //                else
            //                {
            //                    List<int> list = new List<int>();
            //                    list.Add(j);
            //                    bb.Add(n, list);
            //                }
            //            }
            //        }
            //    }
            //}
            //ExcludeGruppe_do(bb, r, a);

            ////同列
            //Dictionary<int, List<int>> bbb = new Dictionary<int, List<int>>();
            //string l = "line";
            //for (int j = 0; j < 9; j++)
            //{
            //    if (textBoxList[j, b].Text == "")//对每个textBox内的小array进行寻找
            //    {
            //        for (int n = 1; n < 10; n++)//有没有元素1-9
            //        {
            //            if (emptyList[j, b].Contains(n))
            //            {
            //                if (bbb.ContainsKey(n))
            //                {
            //                    bbb[n].Add(j);
            //                }
            //                else
            //                {
            //                    List<int> list = new List<int>();
            //                    list.Add(j);
            //                    bbb.Add(n, list);
            //                }
            //            }
            //        }
            //    }
            //}
            //ExcludeGruppe_do(bbb, l, b);
            #endregion
            //3*3组
            Dictionary<int, List<int>> bbbb = new Dictionary<int, List<int>>();
            string box = "3*3";
            for (int i = 3 * (a / 3); i < 3 * (a / 3) + 3; i++)
            {
                for (int j = 3 * (b / 3); j < 3 * (b / 3) + 3; j++)
                {
                    if (textBoxList[i, j].Text == "")//对每个textBox内的小array进行寻找
                    {
                        for (int n = 1; n < 10; n++)//有没有元素1-9
                        {
                            if (emptyList[i, j].Contains(n))
                            {
                                if (bbbb.ContainsKey(n))
                                {
                                    bbbb[n].Add(j);
                                }
                                else
                                {
                                    List<int> list = new List<int>();
                                    list.Add(j);
                                    bbbb.Add(n, list);
                                }
                            }
                        }
                    }
                }
            }
            ExcludeGruppe_do(bbbb, box, 3 * (a / 3), 3 * (b / 3));
        }

        /// <summary>
        /// 反转字典,找到位置相同的值,
        /// 先清空(n,n)位置的数组,
        /// 再删掉其他地方的这个值,
        /// 再把n挨个添加到(n,n)数组里
        /// </summary>
        /// <param name="b"></param>
        /// <param name="str"></param>
        /// <param name="i"></param>
        public void ExcludeGruppe_do(Dictionary<int, List<int>> bb, string str, int i, int j = 1)
        {
            var result = bb
                        .GroupBy(z => String.Join(";", z.Value));//把list换成string比较的
                                                                 //.Where(z => z.Count() > 1);
            foreach (var group in result)
            {
                if ((group.Key.Length + 1) / 2 == group.Count())//有且仅有n个
                {
                    //(n,n)数组位置
                    int[] ints = group.Key.Split(new[] { ';' }).Select(n => Convert.ToInt32(n)).ToArray();
                    foreach (var item in ints)//先清除组里(n,n)位置的所有元素
                    {
                        switch (str)
                        {
                            case "row":
                                if (textBoxList[i, item].Text == "")
                                {
                                    emptyList[i, item].Clear();
                                }
                                break;
                            case "line":
                                if (textBoxList[item, i].Text == "")
                                {
                                    emptyList[item, i].Clear();
                                }
                                break;
                            case "3*3":
                                if (item >= 6)
                                {
                                    if (textBoxList[i + 2, j + item - 6].Text == "")
                                    {
                                        emptyList[i + 2, j + item - 6].Clear();
                                    }
                                }
                                else if (item >= 3)
                                {
                                    if (textBoxList[i + 1, j + item - 3].Text == "")
                                    {
                                        emptyList[i + 1, j + item - 3].Clear();
                                    }
                                }
                                else
                                {
                                    if (textBoxList[i, j + item].Text == "")
                                    {
                                        emptyList[i, j + item].Clear();
                                    }
                                }
                                break;
                        }

                    }
                    for (int d = 0; d < 9; d++)//当前位置d
                    {
                        foreach (var ii in group)
                        {
                            if (!ints.Contains(d)) //当前位置d,需删除(n, n)元素
                            {
                                switch (str)
                                {
                                    case "row":
                                        if (textBoxList[i, d].Text == "")
                                        { emptyList[i, d].Remove(ii.Key); }
                                        break;
                                    case "line":
                                        if (textBoxList[d, i].Text == "")
                                        { emptyList[d, i].Remove(ii.Key); }
                                        break;
                                    case "3*3":
                                        if (d >= 6)
                                        {
                                            if (textBoxList[i + 2, j + d - 6].Text == "")
                                            { emptyList[i + 2, j + d - 6].Remove(ii.Key); }
                                        }
                                        else if (d >= 3)
                                        {
                                            if (textBoxList[i + 1, j + d - 3].Text == "")
                                            { emptyList[i + 1, j + d - 3].Remove(ii.Key); }
                                        }
                                        else
                                        {
                                            if (textBoxList[i, j + d].Text == "")
                                            { emptyList[i, j + d].Remove(ii.Key); }
                                        }
                                        break;
                                }
                            }
                            else
                            {
                                switch (str)//把n添加进去
                                {
                                    case "row":
                                        if (textBoxList[i, d].Text == "")
                                        { emptyList[i, d].Add(ii.Key); }
                                        break;
                                    case "line":
                                        if (textBoxList[d, i].Text == "")
                                        { emptyList[d, i].Add(ii.Key); }
                                        break;
                                    case "3*3":
                                        if (d >= 6)
                                        {
                                            if (textBoxList[i + 2, j + d - 6].Text == "")
                                            { emptyList[i + 2, j + d - 6].Add(ii.Key); }
                                        }
                                        else if (d >= 3)
                                        {
                                            if (textBoxList[i + 1, j + d - 3].Text == "")
                                            { emptyList[i + 1, j + d - 3].Add(ii.Key); }
                                        }
                                        else
                                        {
                                            if (textBoxList[i, j + d].Text == "")
                                            { emptyList[i, j + d].Add(ii.Key); }
                                        }
                                        break;
                                }
                            }

                        }
                    }
                }
            };
        }

        public bool FindPossib3(TextBox[,] tList, List<int>[,] eList, out int a, out int b)
        {
            foreach (var possi3 in tList)
            {
                a = possi3.TabIndex / 9;//行
                b = possi3.TabIndex % 9;//列
                if (possi3.Text == "" && eList[a, b].Count == 3)
                {
                    if (Guess3(eList[a, b][0], a, b) == false)//第一个数猜错
                    {
                        if (Guess3(eList[a, b][1], a, b) == false)//第二个数猜错
                        {
                            if (Guess3(eList[a, b][2], a, b) == false)//第三个数错
                            {
                                return false;
                            }
                            else
                            {
                                z = 2;
                                return true;
                            }
                        }
                        else//第二个数猜对
                        {
                            z = 1;
                            return true;
                        }
                    }
                    else//第一个数猜对,更新两张表
                    {
                        z = 0;
                        textBoxList = itextBoxList;
                        emptyList = iemptyList;
                        return true;
                    }
                }
            }
            a = 0; b = 0;
            return true;
        }
        public bool FindPossib2(TextBox[,] tList, List<int>[,] eList, out int a, out int b)
        {
            foreach (var possi2 in tList)
            {
                a = possi2.TabIndex / 9;//行
                b = possi2.TabIndex % 9;//列
                if (possi2.Text == "" && eList[a, b].Count == 2)
                {
                    if (Guess2(eList[a, b][0], a, b) == false)//猜错了的话
                    {
                        //textBoxList[a, b].Text = emptyList[a, b][1].ToString();
                        return false;
                    }
                    else//猜对了,更新两张表
                    {
                        UpDateList(itextBoxList, iemptyList);
                        return true;
                    }
                }
            }
            a = 0; b = 0;
            UpDateList(itextBoxList, iemptyList);
            return true;
        }
        /// <summary>
        /// 操作虚表,试验填数,有错误填数立即返回false
        /// </summary>
        /// <param name="m">候选数1</param>
        /// <param name="a">横坐标</param>
        /// <param name="b">纵坐标</param>
        /// <returns></returns>
        public bool Guess2(int m, int a, int b)
        {
            itextBoxList[a, b].Text = m.ToString();
            while (IfFinished(itextBoxList) == false)
            {
                DeleteRelativNummber(itextBoxList[a, b], itextBoxList, iemptyList);
                //检查有没有不合规的数字,即有一个空格没有任何填数的可能
                foreach (var item in itextBoxList)
                {
                    int i = item.TabIndex / 9;//行
                    int j = item.TabIndex % 9;//列
                    if (item.Text == "" && iemptyList[i, j].Count == 0)
                    {
                        return false;
                    }
                }
                if (!FindPossib2(itextBoxList, iemptyList, out a, out b))
                {
                    return false;
                }
            }
            return true;
        }
        public bool Guess3(int m, int a, int b)
        {
            itextBoxList[a, b].Text = m.ToString();
            while (IfFinished(itextBoxList) == false)
            {
                DeleteRelativNummber(itextBoxList[a, b], itextBoxList, iemptyList);
                //检查有没有不合规的数字,即有一个空格没有任何填数的可能
                foreach (var item in itextBoxList)
                {
                    int i = item.TabIndex / 9;//行
                    int j = item.TabIndex % 9;//列
                    if (item.Text == "" && iemptyList[i, j].Count == 0)
                    {
                        return false;
                    }
                }
                if (!FindPossib2(itextBoxList, iemptyList, out a, out b))
                {
                    return false;
                }
                if (!FindPossib3(itextBoxList, iemptyList, out a, out b))
                {
                    return false;
                }
            }
            return true;
        }
    }
}
